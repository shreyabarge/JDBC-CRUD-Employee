package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTask {
   public static void main(String[] args) {
	   String url = "jdbc:mysql://localhost:3306/PracticeDemo";
	   String username = "root";
	   String password = "root";
	   try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, password);
		if(con!=null) {
			System.out.println("Connected to database..");
		}
		con.close();
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
